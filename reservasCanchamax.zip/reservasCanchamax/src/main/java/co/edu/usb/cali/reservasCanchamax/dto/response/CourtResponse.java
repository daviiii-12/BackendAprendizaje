package co.edu.usb.cali.reservasCanchamax.dto.response;

import lombok.Builder;
import lombok.Getter;

import java.sql.Timestamp;

@Getter
@Builder
public class CourtResponse {

    private Integer id;
    private String name;
    private String location;
    private Boolean isActive;
    private Timestamp createdAt;
    private Timestamp updatedAt;

}