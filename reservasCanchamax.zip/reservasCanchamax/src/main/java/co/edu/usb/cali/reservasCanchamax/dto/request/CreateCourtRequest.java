package co.edu.usb.cali.reservasCanchamax.dto.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateCourtRequest {

    private String name;
    private String location;

}